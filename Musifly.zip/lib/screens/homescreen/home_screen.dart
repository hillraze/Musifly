import "package:flutter/material.dart";
import "package:musifly/widgets/mus.button.dart";
import "package:musifly/widgets/mus.buttonToTest.dart";

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return const Scaffold(
      body: ColoredBox(
        color: Color(0xFF192347),
        child: Column(children: [
          SizedBox(child: Center(child: MusButtonToTest())),
          SizedBox(
            child: Text(''),
          )
        ]),
      ),
    );
  }
}
