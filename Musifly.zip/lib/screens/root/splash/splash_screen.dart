import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:musifly/analytics/events/screen_names.dart';
import 'package:musifly/core/mus.assets/mus.assets.dart';
import 'package:musifly/core/mus.assets/mus.asset_image.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();

    _navigateAway();
  }

  @override
  dispose() {
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return const MusAssetImage(
      MusAssets.loading,
      width: double.infinity,
      height: double.infinity,
    );
  }

  void _navigateAway() async {
    await Future.delayed(Duration(seconds: 3));
    if (mounted) context.go(ScreenNames.onboard);
  }
}
