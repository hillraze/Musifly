import 'package:musifly/core/mus.assets/mus.asset.dart';

class MusAssets {
  const MusAssets._();
  static const loading = MusAsset.bitmap('assets/images/loading.jpg');
  static const getStarted = MusAsset.bitmap('assets/images/get-started.jpg');
}
