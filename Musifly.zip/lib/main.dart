import 'package:flutter/material.dart';
import 'package:musifly/screens/onboarding/onboarding_screen.dart';
import 'screens/root/splash/splash_screen.dart';
import 'screens/homescreen/home_screen.dart';

import 'package:musifly/presentation/navigation/router.dart';

GlobalKey<NavigatorState> screenNavigatorKey = GlobalKey();
GlobalKey<NavigatorState> shellKey = GlobalKey();

void main() {
  RouterService.init(screenNavigatorKey, shellKey);
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp.router(
      routerConfig: RouterService.instance.goRouter,
      theme: ThemeData(
        fontFamily: 'Poppins',
        // elevatedButtonTheme: ElevatedButtonThemeData(
        //   style: ButtonStyle(
        //     textStyle: MaterialStatePropertyAll<TextStyle>(
        //         TextStyle(fontFamily: 'Poppins')),
        //   ),
      ),
    );
    // );
  }
}
